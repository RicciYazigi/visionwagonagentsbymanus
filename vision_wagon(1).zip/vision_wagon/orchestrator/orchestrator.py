
import uuid
import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional
from enum import Enum, auto
from datetime import datetime
from ..agents.core.base_agent import BaseAgent

class WorkflowStatus(Enum):
    CREATED = auto()
    RUNNING = auto()
    PAUSED = auto()
    COMPLETED = auto()
    FAILED = auto()

class Priority(Enum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    CRITICAL = auto()

class TaskStatus(Enum):
    PENDING = auto()
    QUEUED = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()
    RETRYING = auto()

class Task:
    def __init__(
        self,
        task_id: str,
        agent_id: str,
        context: Dict[str, Any],
        priority: Priority = Priority.MEDIUM,
        timeout: int = 30,
        max_retries: int = 3,
        dependencies: List[str] = None
    ):
        self.task_id = task_id
        self.agent_id = agent_id
        self.context = context
        self.priority = priority
        self.timeout = timeout
        self.max_retries = max_retries
        self.dependencies = dependencies or []
        self.status = TaskStatus.PENDING
        self.retry_count = 0
        self.created_at = datetime.utcnow()
        self.started_at = None
        self.completed_at = None
        self.result = None
        self.error = None

class Workflow:
    def __init__(
        self,
        workflow_id: str,
        name: str,
        description: str = "",
        config: Dict[str, Any] = None,
        metadata: Dict[str, Any] = None
    ):
        self.workflow_id = workflow_id
        self.name = name
        self.description = description
        self.config = config or {}
        self.metadata = metadata or {}
        self.status = WorkflowStatus.CREATED
        self.tasks: Dict[str, Task] = {}
        self.created_at = datetime.utcnow()

    def add_task(self, task: Task):
        self.tasks[task.task_id] = task

    def get_task(self, task_id: str) -> Optional[Task]:
        return self.tasks.get(task_id)

    def update_task_status(self, task_id: str, status: TaskStatus, result: Optional[Dict[str, Any]] = None, error: Optional[str] = None):
        task = self.tasks.get(task_id)
        if task:
            task.status = status
            task.result = result
            task.error = error
            if status in [TaskStatus.COMPLETED, TaskStatus.FAILED]:
                task.completed_at = datetime.utcnow()
            elif status == TaskStatus.RUNNING:
                task.started_at = datetime.utcnow()

class Orchestrator:
    def __init__(self, agents: Dict[str, BaseAgent]):
        self.workflows: Dict[str, Workflow] = {}
        self.agents = agents

    def create_workflow(self, name: str, description: str = "", config: Dict[str, Any] = None, metadata: Dict[str, Any] = None) -> Workflow:
        workflow_id = str(uuid.uuid4())
        workflow = Workflow(workflow_id, name, description, config, metadata)
        self.workflows[workflow_id] = workflow
        return workflow

    def get_workflow(self, workflow_id: str) -> Optional[Workflow]:
        return self.workflows.get(workflow_id)

    async def execute_workflow(self, workflow_id: str) -> Dict[str, Any]:
        workflow = self.get_workflow(workflow_id)
        if not workflow:
            return {"status": "error", "message": f"Workflow {workflow_id} no encontrado"}

        workflow.status = WorkflowStatus.RUNNING
        results = {}

        # Simple sequential execution for now; can be extended with dependency graph
        for task_id, task in workflow.tasks.items():
            if task.agent_id not in self.agents:
                workflow.update_task_status(task_id, TaskStatus.FAILED, error=f"Agente {task.agent_id} no encontrado")
                results[task_id] = {"status": "error", "error": f"Agente {task.agent_id} no encontrado"}
                continue

            agent = self.agents[task.agent_id]
            workflow.update_task_status(task_id, TaskStatus.RUNNING)
            try:
                task_result = await agent.execute(task.context)
                if task_result.get("status") == "error":
                    workflow.update_task_status(task_id, TaskStatus.FAILED, result=task_result, error=task_result.get("error"))
                else:
                    workflow.update_task_status(task_id, TaskStatus.COMPLETED, result=task_result)
                results[task_id] = task_result
            except Exception as e:
                workflow.update_task_status(task_id, TaskStatus.FAILED, error=str(e))
                results[task_id] = {"status": "error", "error": str(e)}

        all_succeeded = all(r.get("status") != "error" for r in results.values())
        workflow.status = WorkflowStatus.COMPLETED if all_succeeded else WorkflowStatus.FAILED

        return {"status": workflow.status.name, "workflow_id": workflow_id, "task_results": results}

    def load_workflow_from_yaml(self, yaml_path: Path) -> Workflow:
        with open(yaml_path, 'r') as f:
            workflow_data = yaml.safe_load(f)

        workflow = self.create_workflow(workflow_data["name"], workflow_data.get("description", ""), workflow_data.get("config", {}), workflow_data.get("metadata", {}))

        for task_data in workflow_data.get("tasks", []):
            task = Task(
                task_id=task_data["id"],
                agent_id=task_data["agent_id"],
                context=task_data["context"],
                priority=Priority[task_data.get("priority", "MEDIUM").upper()],
                timeout=task_data.get("timeout", 30),
                max_retries=task_data.get("max_retries", 3),
                dependencies=task_data.get("dependencies", [])
            )
            workflow.add_task(task)
        return workflow


