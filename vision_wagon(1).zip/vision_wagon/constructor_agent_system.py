
import os
import json
import yaml
import asyncio
import logging
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
from abc import ABC, abstractmethod
import subprocess
import tempfile
import shutil

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ========== MODELOS DE DATOS ==========
@dataclass
class TaskResult:
    """Resultado de una tarea ejecutada"""
    task_name: str
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    artifacts_created: List[str] = field(default_factory=list)

@dataclass
class BuildContext:
    """Contexto de construcción con toda la información necesaria"""
    project_root: Path
    blueprint_path: Path
    target_module: Optional[str] = None
    target_agent: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class AgentSpec:
    """Especificación de un agente"""
    name: str
    type: str  # 'executive' | 'operational'
    description: str
    dependencies: List[str] = field(default_factory=list)
    methods: List[Dict[str, Any]] = field(default_factory=list)
    config: Dict[str, Any] = field(default_factory=dict)

# ========== PLANTILLAS DE CÓDIGO ==========
class CodeTemplates:
    """Plantillas de código reutilizables"""

    @staticmethod
    def agent_base_template(agent_spec: AgentSpec) -> str:
        """Plantilla base para agentes"""
        return f'''"""
{agent_spec.name} - Vision Wagon Agent Tipo: {agent_spec.type.title()} Descripción:
{agent_spec.description}
Generado automáticamente por ConstructorAgent
"""
import asyncio
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from ..core.base_agent import BaseAgent
from ...database.database_models import AgentLog, Campaign

logger = logging.getLogger(__name__)

class {agent_spec.name}(BaseAgent):
    """ {agent_spec.description} """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(
            agent_id="{agent_spec.name.lower()}",
            agent_type="{agent_spec.type}",
            config=config or {{}}
        )
        self.dependencies = {json.dumps(agent_spec.dependencies)}

    async def initialize(self) -> bool:
        """Inicializa el agente y sus dependencias"""
        try:
            logger.info(f"Inicializando {{self.agent_id}}")
            # TODO: Implementar inicialización específica
            return True
        except Exception as e:
            logger.error(f"Error inicializando {{self.agent_id}}: {{e}}")
            return False

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Procesa la tarea principal del agente"""
        try:
            await self.log_action("process_start", context)
            # TODO: Implementar lógica de procesamiento
            result = {{
                "status": "completed",
                "agent": self.agent_id,
                "timestamp": datetime.utcnow().isoformat(),
                "data": {{}}
            }}
            await self.log_action("process_complete", result)
            return result
        except Exception as e:
            error_result = {{
                "status": "error",
                "agent": self.agent_id,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }}
            await self.log_action("process_error", error_result)
            return error_result

    async def validate_input(self, data: Dict[str, Any]) -> bool:
        """Valida los datos de entrada"""
        # TODO: Implementar validación específica
        return True

    async def cleanup(self) -> None:
        """Limpieza de recursos"""
        logger.info(f"Limpiando recursos de {{self.agent_id}}")
        # TODO: Implementar limpieza específica

'''

    @staticmethod
    def database_model_template(model_name: str, fields: List[Dict[str, Any]]) -> str:
        """Plantilla para modelos de base de datos"""
        field_definitions = []
        relationships = []
        for field_info in fields:
            field_name = field_info["name"]
            field_type = field_info["type"]
            field_options = field_info.get("options", {})
            if field_info.get("is_relationship", False):
                relationships.append(f"    {field_name} = relationship(\"{field_info["related_model"]}\")")
            else:
                options_str = ", ".join([f"{k}={v}" for k, v in field_options.items()])
                if options_str:
                    field_definitions.append(f"    {field_name} = Column({field_type}, {options_str})")
                else:
                    field_definitions.append(f"    {field_name} = Column({field_type})")
        fields_code = "\n".join(field_definitions)
        relationships_code = "\n".join(relationships) if relationships else ""

        return f'''from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime
import uuid

Base = declarative_base()

class {model_name}(Base):
    """ Modelo {model_name} - Generado por ConstructorAgent """
    __tablename__ = \'{model_name.lower()}s\'

{fields_code}
{relationships_code}

    def __repr__(self):
        return f"<{model_name}(id={{self.id}})>"

    def to_dict(self):
        """Convierte el modelo a diccionario"""
        return {{c.name: getattr(self, c.name) for c in self.__table__.columns}}

'''

    @staticmethod
    def api_endpoint_template(endpoint_spec: Dict[str, Any]) -> str:
        """Plantilla para endpoints de API"""
        method = endpoint_spec["method"].upper()
        path = endpoint_spec["path"]
        function_name = endpoint_spec["function_name"]
        description = endpoint_spec.get("description", "")
        return f'''@app.{method.lower()}("{path}")
async def {function_name}( # TODO: Añadir parámetros según especificación ):
    """
    {description}
    """
    try:
        # TODO: Implementar lógica del endpoint
        return {{"status": "success", "message": "Endpoint implementado"}}
    except Exception as e:
        logger.error(f"Error en {function_name}: {{e}}")
        raise HTTPException(status_code=500, detail=str(e))
'''

# ========== TAREAS DE CONSTRUCCIÓN ==========
class BuildTask(ABC):
    """Clase base para tareas de construcción"""
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description

    @abstractmethod
    async def execute(self, context: BuildContext) -> TaskResult:
        """Ejecuta la tarea"""
        pass

class InitProjectStructureTask(BuildTask):
    """Tarea para inicializar la estructura del proyecto"""
    def __init__(self):
        super().__init__(
            "init_project_structure",
            "Crea la estructura de directorios base del proyecto"
        )

    async def execute(self, context: BuildContext) -> TaskResult:
        """Crea la estructura de directorios"""
        start_time = datetime.now()
        artifacts = []
        try:
            directories = [
                "agents/executive",
                "agents/operational",
                "agents/core",
                "database",
                "api",
                "orchestrator",
                "tests/agents",
                "tests/api",
                "tests/database",
                "config",
                "blueprints",
                "logs",
                "docs"
            ]
            for dir_path in directories:
                full_path = context.project_root / dir_path
                full_path.mkdir(parents=True, exist_ok=True)
                if any(dir_path.startswith(prefix) for prefix in ["agents", "database", "api", "orchestrator"]):
                    init_file = full_path / "__init__.py"
                    init_file.write_text(""""""Vision Wagon - Generado por ConstructorAgent"""""")
                    artifacts.append(str(init_file))

            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=True,
                output=f"Creados {len(directories)} directorios",
                execution_time=execution_time,
                artifacts_created=artifacts
            )
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=False,
                error=str(e),
                execution_time=execution_time
            )

class GenerateConfigFilesTask(BuildTask):
    """Tarea para generar archivos de configuración"""
    def __init__(self):
        super().__init__(
            "generate_config_files",
            "Genera archivos de configuración esenciales como requirements.txt y .gitignore"
        )

    async def execute(self, context: BuildContext) -> TaskResult:
        start_time = datetime.now()
        artifacts = []
        try:
            # requirements.txt
            requirements_content = """
fastapi
uvicorn
sqlalchemy
psycopg2-binary # or other database driver
python-dotenv
httpx
pyyaml
typing-extensions # For Python < 3.9, if needed for dataclasses
"""
            requirements_path = context.project_root / "requirements.txt"
            requirements_path.write_text(requirements_content)
            artifacts.append(str(requirements_path))

            # .gitignore
            gitignore_content = """
# Byte-code files
*.pyc
__pycache__/

# IDE-specific files
.vscode/
.idea/

# Virtual environment
venv/
.env

# Logs
*.log
logs/

# Database
*.db
*.sqlite3

# Uploaded files
/upload/

# Generated files
/generated/

# Other
.DS_Store
"""
            gitignore_path = context.project_root / ".gitignore"
            gitignore_path.write_text(gitignore_content)
            artifacts.append(str(gitignore_path))

            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=True,
                output="Archivos de configuración generados",
                execution_time=execution_time,
                artifacts_created=artifacts
            )
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=False,
                error=str(e),
                execution_time=execution_time
            )

class ScaffoldAgentTask(BuildTask):
    """Tarea para fabricar el archivo .py de un nuevo agente"""
    def __init__(self):
        super().__init__(
            "scaffold_agent",
            "Fabrica el archivo .py de un nuevo agente utilizando la especificación"
        )

    async def execute(self, context: BuildContext) -> TaskResult:
        start_time = datetime.now()
        artifacts = []
        try:
            if not context.target_agent:
                raise ValueError("target_agent no especificado para ScaffoldAgentTask")

            agent_spec_data = context.config.get("agent_specs", {}).get(context.target_agent)
            if not agent_spec_data:
                raise ValueError(f"Especificación de agente no encontrada para: {context.target_agent}")

            agent_spec = AgentSpec(**agent_spec_data)
            agent_content = CodeTemplates.agent_base_template(agent_spec)

            agent_dir = context.project_root / "agents" / agent_spec.type
            agent_file_path = agent_dir / f"{agent_spec.name.lower()}.py"
            agent_file_path.write_text(agent_content)
            artifacts.append(str(agent_file_path))

            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=True,
                output=f"Agente {agent_spec.name} fabricado en {agent_file_path}",
                execution_time=execution_time,
                artifacts_created=artifacts
            )
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            return TaskResult(
                task_name=self.name,
                success=False,
                error=str(e),
                execution_time=execution_time
            )

class BlueprintParser:
    """Clase para leer y parsear archivos de blueprint (YAML)"""
    def parse(self, blueprint_path: Path) -> Dict[str, Any]:
        if not blueprint_path.exists():
            raise FileNotFoundError(f"Blueprint no encontrado: {blueprint_path}")
        with open(blueprint_path, 'r') as f:
            blueprint_data = yaml.safe_load(f)
        # TODO: Add schema validation for blueprint_data
        return blueprint_data

class ConstructorAgent:
    """El Maestro de Obra: dirige toda la operación de construcción"""
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.tasks_registry: Dict[str, BuildTask] = {
            "init_project_structure": InitProjectStructureTask(),
            "generate_config_files": GenerateConfigFilesTask(),
            "scaffold_agent": ScaffoldAgentTask()
        }
        self.execution_history: List[TaskResult] = []
        self.blueprint_parser = BlueprintParser()

    async def _plan_execution(self, blueprint_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        plan = []
        # Always start with project structure and config files
        plan.append({"task": "init_project_structure"})
        plan.append({"task": "generate_config_files"})

        # Add agent scaffolding tasks
        agent_specs = blueprint_data.get("agents", {})
        for agent_name, spec in agent_specs.items():
            plan.append({"task": "scaffold_agent", "target_agent": agent_name, "config": {"agent_specs": agent_specs}})

        # TODO: Add more complex planning logic based on blueprint
        return plan

    async def build_from_blueprint(self, blueprint_path: Path) -> List[TaskResult]:
        logger.info(f"Iniciando construcción desde blueprint: {blueprint_path}")
        results = []
        try:
            blueprint_data = self.blueprint_parser.parse(blueprint_path)
            execution_plan = await self._plan_execution(blueprint_data)

            for item in execution_plan:
                task_name = item["task"]
                task = self.tasks_registry.get(task_name)
                if not task:
                    result = TaskResult(task_name=task_name, success=False, error=f"Tarea desconocida: {task_name}")
                    results.append(result)
                    self.execution_history.append(result)
                    continue

                context = BuildContext(
                    project_root=self.project_root,
                    blueprint_path=blueprint_path,
                    target_agent=item.get("target_agent"),
                    config=item.get("config", {})
                )
                logger.info(f"Ejecutando tarea: {task.name}...")
                result = await task.execute(context)
                results.append(result)
                self.execution_history.append(result)

                if not result.success:
                    logger.error(f"Tarea {task.name} falló: {result.error}")
                    # Depending on severity, might stop or continue
                    # For now, we'll continue to show all failures

        except Exception as e:
            logger.error(f"Error general en la construcción: {e}")
            results.append(TaskResult(task_name="overall_build", success=False, error=str(e)))

        logger.info("Construcción finalizada.")
        return results

    def get_status(self) -> List[TaskResult]:
        return self.execution_history

    def validate_blueprint(self, blueprint_path: Path) -> Dict[str, Any]:
        try:
            self.blueprint_parser.parse(blueprint_path)
            return {"status": "success", "message": "Blueprint válido"}
        except Exception as e:
            return {"status": "error", "message": f"Error de validación de blueprint: {e}"}

    def generate_template(self, template_type: str) -> str:
        if template_type == "agent_spec":
            return yaml.dump({
                "agents": {
                    "ExampleAgent": {
                        "name": "ExampleAgent",
                        "type": "executive",
                        "description": "Un agente de ejemplo.",
                        "dependencies": [],
                        "methods": [
                            {"name": "process_data", "description": "Procesa datos de entrada."}
                        ],
                        "config": {"param1": "value1"}
                    }
                }
            }, sort_keys=False)
        elif template_type == "blueprint":
            return yaml.dump({
                "project_name": "MyVisionWagonProject",
                "agents": {
                    "IntelligenceAgent": {
                        "name": "IntelligenceAgent",
                        "type": "executive",
                        "description": "Agente para análisis de inteligencia."
                    },
                    "CopywriterAgent": {
                        "name": "CopywriterAgent",
                        "type": "operational",
                        "description": "Agente para generación de contenido."
                    }
                },
                "database_models": [
                    {"name": "User", "fields": [{"name": "id", "type": "Integer"}, {"name": "name", "type": "String"}]}
                ],
                "api_endpoints": [
                    {"method": "GET", "path": "/users", "function_name": "get_users", "description": "Obtiene todos los usuarios."}
                ]
            }, sort_keys=False)
        else:
            return "Tipo de plantilla desconocido."


