

import argparse
import asyncio
import logging
from pathlib import Path
from constructor_agent_system import ConstructorAgent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def main():
    parser = argparse.ArgumentParser(description="CLI para ConstructorAgent de Vision Wagon")
    parser.add_argument("--project_root", type=str, default=".",
                        help="Ruta raíz del proyecto Vision Wagon (por defecto: .)")

    subparsers = parser.add_subparsers(dest="command", help="Comandos disponibles")

    # Comando init
    init_parser = subparsers.add_parser("init", help="Inicializa la estructura del proyecto Vision Wagon")

    # Comando build
    build_parser = subparsers.add_parser("build", help="Construye el proyecto a partir de un blueprint")
    build_parser.add_argument("--blueprint", type=str, required=True,
                              help="Ruta al archivo blueprint YAML")

    # Comando status
    status_parser = subparsers.add_parser("status", help="Muestra el estado actual del proyecto y el historial de construcción")

    # Comando validate
    validate_parser = subparsers.add_parser("validate", help="Valida un archivo blueprint YAML")
    validate_parser.add_argument("--blueprint", type=str, required=True,
                                 help="Ruta al archivo blueprint YAML a validar")

    # Comando generate
    generate_parser = subparsers.add_parser("generate", help="Genera plantillas de blueprint o especificaciones de agente")
    generate_parser.add_argument("--type", type=str, choices=["blueprint", "agent_spec"], required=True,
                                 help="Tipo de plantilla a generar (blueprint o agent_spec)")
    generate_parser.add_argument("--output", type=str, default="-",
                                 help="Archivo de salida para la plantilla (por defecto: stdout)")

    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    constructor = ConstructorAgent(project_root)

    if args.command == "init":
        logger.info("Inicializando estructura del proyecto...")
        context = constructor.tasks_registry["init_project_structure"].execute(BuildContext(project_root=project_root, blueprint_path=Path("dummy")))
        config_context = constructor.tasks_registry["generate_config_files"].execute(BuildContext(project_root=project_root, blueprint_path=Path("dummy")))
        results = [await context, await config_context]
        for result in results:
            if result.success:
                logger.info(f"Tarea '{result.task_name}' completada: {result.output}")
                for artifact in result.artifacts_created:
                    logger.info(f"  - Creado: {artifact}")
            else:
                logger.error(f"Tarea '{result.task_name}' falló: {result.error}")

    elif args.command == "build":
        blueprint_path = Path(args.blueprint).resolve()
        logger.info(f"Construyendo desde blueprint: {blueprint_path}...")
        results = await constructor.build_from_blueprint(blueprint_path)
        for result in results:
            if result.success:
                logger.info(f"Tarea '{result.task_name}' completada: {result.output}")
                for artifact in result.artifacts_created:
                    logger.info(f"  - Creado: {artifact}")
            else:
                logger.error(f"Tarea '{result.task_name}' falló: {result.error}")

    elif args.command == "status":
        logger.info("Estado del proyecto y historial de construcción:")
        history = constructor.get_status()
        if not history:
            logger.info("No hay historial de construcción disponible.")
        for entry in history:
            status = "ÉXITO" if entry.success else "FALLO"
            logger.info(f"- Tarea: {entry.task_name}, Estado: {status}, Tiempo: {entry.execution_time:.2f}s")
            if entry.error:
                logger.error(f"  Error: {entry.error}")
            if entry.artifacts_created:
                logger.info(f"  Artefactos: {', '.join(entry.artifacts_created)}")

    elif args.command == "validate":
        blueprint_path = Path(args.blueprint).resolve()
        logger.info(f"Validando blueprint: {blueprint_path}...")
        validation_result = constructor.validate_blueprint(blueprint_path)
        if validation_result["status"] == "success":
            logger.info(f"Blueprint válido: {validation_result["message"]}")
        else:
            logger.error(f"Blueprint inválido: {validation_result["message"]}")

    elif args.command == "generate":
        template_content = constructor.generate_template(args.type)
        if args.output == "-":
            print(template_content)
        else:
            output_path = Path(args.output).resolve()
            output_path.write_text(template_content)
            logger.info(f"Plantilla '{args.type}' generada en: {output_path}")

    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())


