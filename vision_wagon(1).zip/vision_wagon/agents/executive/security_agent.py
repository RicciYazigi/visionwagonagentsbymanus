

from datetime import datetime
from typing import Dict, Any, List, Optional
from enum import Enum
from ..core.base_agent import BaseAgent
from ...security.security_validator import SecurityValidator

class SecurityEventType(Enum):
    AUTHENTICATION = "authentication"
    INPUT_VALIDATION = "input_validation"
    SYSTEM_ACCESS = "system_access"
    CONFIG_CHANGE = "config_change"

class ThreatLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SecurityAgent(BaseAgent):
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__("security_agent", "executive", config)
        self.security_events: List[Dict[str, Any]] = []
        self.max_events_history = config.get("max_events_history", 1000)
        self.validator = SecurityValidator()

    async def initialize(self) -> bool:
        self.logger.info("Inicializando SecurityAgent...")
        # Aquí se podría cargar el historial de eventos de seguridad desde una DB
        return True

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        event_type = context.get("event_type")
        threat_level = context.get("threat_level")
        description = context.get("description")
        source_ip = context.get("source_ip")
        user_agent = context.get("user_agent")
        payload = context.get("payload")

        if not all([event_type, threat_level, description]):
            return {"status": "error", "message": "Faltan parámetros para log_security_event"}

        await self.log_security_event(
            SecurityEventType[event_type.upper()],
            ThreatLevel[threat_level.upper()],
            source_ip,
            user_agent,
            payload,
            description
        )
        return {"status": "success", "message": "Evento de seguridad registrado"}

    async def validate_input(self, data: Dict[str, Any]) -> bool:
        required_fields = ["event_type", "threat_level", "description"]
        if not all(field in data for field in required_fields):
            self.logger.error(f"Faltan campos requeridos para SecurityAgent: {required_fields}")
            return False
        return True

    async def cleanup(self) -> None:
        self.logger.info("Limpiando recursos de SecurityAgent...")
        self.security_events.clear()

    async def generate_security_report(self, report_type: str = "summary") -> Dict[str, Any]:
        recent_events = [e for e in self.security_events if (datetime.utcnow() - e["timestamp"]).days < 7]
        threat_counts = {level.name: 0 for level in ThreatLevel}
        type_counts = {type.name: 0 for type in SecurityEventType}

        for event in recent_events:
            threat_counts[event["threat_level"].name] += 1
            type_counts[event["event_type"].name] += 1

        report = {
            "status": "success",
            "report_type": report_type,
            "time_range": "7d",
            "total_events": len(recent_events),
            "threat_distribution": threat_counts,
            "event_types": type_counts
        }

        if report_type == "detailed":
            report["recent_events"] = [
                {
                    "event_id": e["event_id"],
                    "type": e["event_type"].value,
                    "threat_level": e["threat_level"].value,
                    "description": e["description"],
                    "timestamp": e["timestamp"].isoformat(),
                    "source_ip": e["source_ip"]
                }
                for e in recent_events[-50:]
            ]
        return report

    async def log_security_event(self,
                                 event_type: SecurityEventType,
                                 threat_level: ThreatLevel,
                                 source_ip: Optional[str],
                                 user_agent: Optional[str],
                                 payload: Optional[str],
                                 description: str):
        event = {
            "event_id": f"sec_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}_{len(self.security_events)}",
            "event_type": event_type,
            "threat_level": threat_level,
            "source_ip": source_ip,
            "user_agent": user_agent,
            "payload": payload,
            "description": description,
            "timestamp": datetime.utcnow(),
            "metadata": {}
        }
        self.security_events.append(event)
        if len(self.security_events) > self.max_events_history:
            self.security_events = self.security_events[self.max_events_history:]
        await self.log_action("security_event", {
            "event_type": event_type.value,
            "threat_level": threat_level.value,
            "source_ip": source_ip,
            "description": description
        }, "warning" if threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL] else "info")


