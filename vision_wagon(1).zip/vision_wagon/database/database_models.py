

""" Modelos de base de datos para Vision Wagon """
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean,
ForeignKey, JSON
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid

Base = declarative_base()

class Campaign(Base):
    """Modelo de campaña"""
    __tablename__ = 'campaigns'

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(UUID(as_uuid=True), default=uuid.uuid4, unique=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    status = Column(String(50), default='pending')
    campaign_type = Column(String(100))
    target_audience = Column(String(255))
    budget = Column(Integer) # En centavos
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    config = Column(JSON)
    metadata = Column(JSON)

    logs = relationship("AgentLog", back_populates="campaign")
    executions = relationship("CampaignExecution", back_populates="campaign")

    def __repr__(self):
        return f"<Campaign(id={self.id}, name='{self.name}', status='{self.status}')>"

    def to_dict(self):
        return {
            "id": self.id,
            "uuid": str(self.uuid),
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "campaign_type": self.campaign_type,
            "target_audience": self.target_audience,
            "budget": self.budget,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "config": self.config,
            "metadata": self.metadata
        }

class AgentLog(Base):
    """Modelo de logs de agentes"""
    __tablename__ = 'agent_logs'

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(String(100), nullable=False, index=True)
    campaign_id = Column(Integer, ForeignKey('campaigns.id'), nullable=True)
    action = Column(String(100), nullable=False)
    status = Column(String(50), default='info')
    message = Column(Text)
    data = Column(JSON)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    execution_time = Column(Integer) # En milisegundos

    campaign = relationship("Campaign", back_populates="logs")

    def __repr__(self):
        return f"<AgentLog(id={self.id}, agent='{self.agent_id}', action='{self.action}')>"

    def to_dict(self):
        return {
            "id": self.id,
            "agent_id": self.agent_id,
            "campaign_id": self.campaign_id,
            "action": self.action,
            "status": self.status,
            "message": self.message,
            "data": self.data,
            "timestamp": self.timestamp.isoformat(),
            "execution_time": self.execution_time
        }

class CampaignExecution(Base):
    """Modelo de ejecución de campaña"""
    __tablename__ = 'campaign_executions'

    id = Column(Integer, primary_key=True, index=True)
    campaign_id = Column(Integer, ForeignKey('campaigns.id'), nullable=False)
    status = Column(String(50), default='started')
    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime)
    result = Column(JSON)

    campaign = relationship("Campaign", back_populates="executions")

    def __repr__(self):
        return f"<CampaignExecution(id={self.id}, campaign_id={self.campaign_id}, status='{self.status}')>"

    def to_dict(self):
        return {
            "id": self.id,
            "campaign_id": self.campaign_id,
            "status": self.status,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "result": self.result
        }


