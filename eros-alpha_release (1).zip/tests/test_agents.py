import pytest
from vision_wagon.agents.operational.eroswriter_agent import ErosWriterAgent
from vision_wagon.agents.operational.assembly_agent import AssemblyAgent
from vision_wagon.agents.executive.adult_compliance_agent import AdultComplianceAgent
from vision_wagon.agents.operational.traffic_capture_agent import TrafficCaptureAgent

@pytest.fixture
def eros_writer_agent():
    return ErosWriterAgent()

@pytest.fixture
def assembly_agent():
    return AssemblyAgent()

@pytest.fixture
def adult_compliance_agent():
    return AdultComplianceAgent()

@pytest.fixture
def traffic_capture_agent():
    return TrafficCaptureAgent()

def test_capabilities(eros_writer_agent, assembly_agent, adult_compliance_agent, traffic_capture_agent):
    assert eros_writer_agent.has_capability("cultural_adaptation")
    assert assembly_agent.has_capability("erotic_content_assembly")
    assert adult_compliance_agent.has_capability("age_verification_meta_check")
    assert traffic_capture_agent.has_capability("teaser_generation")
