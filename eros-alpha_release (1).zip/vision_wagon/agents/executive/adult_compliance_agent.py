from vision_wagon.agents.base_agent import BaseAgent

class AdultComplianceAgent(BaseAgent):
    def __init__(self,name='AdultComplianceAgent',capabilities=None):
        super().__init__(name, capabilities or ['age_verification_meta_check','jurisdiction_filter','platform_policy_check'])

    def run_compliance_check(self,package:dict,jurisdiction:str,policies:list[str])->bool:
        if package.get('metadata',{}).get('age_rating')!='18+':
            return False
        if jurisdiction=='Germany' and 'explicit sexual act' in package.get('narrative','').lower():
            return False
        for p in policies:
            if p.lower() in package.get('narrative','').lower():
                return False
        return True
