from vision_wagon.agents.base_agent import BaseAgent

class ErosWriterAgent(BaseAgent):
    def __init__(self, name='ErosWriterAgent', capabilities=None):
        super().__init__(name, capabilities or [
            'cultural_adaptation','cliffhanger_creation','character_consistency'
        ])

    def generate_narrative(self, prompt:str, cultural_context:str, existing_narrative:str='')->str:
        print(f'Generating narrative for {prompt} in context {cultural_context}')
        if existing_narrative:
            return f"{existing_narrative} ... (continued, cliffhanger, adapted for {cultural_context})"
        return f"Erotic narrative about {prompt}, cliffhanger, adapted for {cultural_context}."
