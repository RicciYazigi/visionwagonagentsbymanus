from vision_wagon.agents.base_agent import BaseAgent

class TrafficCaptureAgent(BaseAgent):
    def __init__(self,name='TrafficCaptureAgent',capabilities=None):
        super().__init__(name, capabilities or ['teaser_generation','social_media_posting','engagement_monitoring'])

    def generate_teaser(self,package:dict)->str:
        snippet=package.get('narrative','').split('.')[0]
        return f'¡Prepárate! Adelanto: {snippet}...'
